__version__ = "1.2.1"
__author__ = 'Ricardo Vergel, Edward Silva, Luis Rueda and Elkim Roa',
def __init__():
	print("aconnect library")
